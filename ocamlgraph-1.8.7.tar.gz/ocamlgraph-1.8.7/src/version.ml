let version = "1.8.7"
let date = "mardi 12 avril 2016, 08:47:44 (UTC+0200)"
