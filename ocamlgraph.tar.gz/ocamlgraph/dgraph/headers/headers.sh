#! /bin/sh
headache -c headers/headache_config.txt -h headers/CEA_LGPL *.ml* *Makefile*
